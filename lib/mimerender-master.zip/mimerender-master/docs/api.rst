API
===

.. autoclass:: mimerender.MimeRenderBase
  :members: __call__, map_exceptions

