.. :changelog:

History
-------

`See release notes 
<https://github.com/gunthercox/jsondb/releases>`_
